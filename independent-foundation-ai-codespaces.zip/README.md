# Independent Foundation AI — MVP

MVP executável de uma IA de investigação independente.

Inclui:
- FastAPI
- interface web
- memória SQLite
- hipóteses e confiança
- memória de erros
- filtros de domínio
- modo Deep Research (estrutura)
- laboratório matemático limitado
- arquitetura pronta para conectar um LLM real

## Instalação

Python 3.11+ recomendado.

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

Linux/macOS:
```bash
source .venv/bin/activate
```

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Abra http://127.0.0.1:8000

## Importante

O MVP usa inicialmente um provider local de demonstração. Ele não finge possuir consciência e não inventa acesso a fontes.

Para obter investigação de linguagem avançada, conecte `app/llm.py` a um modelo local ou API de LLM.

## Próximas fases

1. LLM real
2. pesquisa web com fontes verificáveis
3. motor matemático simbólico
4. grafo de conhecimento
5. sandbox isolado em containers
6. avaliação e benchmarks
