import math

def simple_numeric_test(expression: str, x_values):
    """Sandbox limitado; não executa código arbitrário."""
    allowed = {
        "x": 0, "sin": math.sin, "cos": math.cos,
        "sqrt": math.sqrt, "log": math.log, "pi": math.pi
    }
    results = []
    for x in x_values[:10000]:
        env = dict(allowed)
        env["x"] = float(x)
        try:
            value = eval(expression, {"__builtins__": {}}, env)
            results.append({"x": x, "value": float(value)})
        except Exception:
            results.append({"x": x, "value": None})
    return results
