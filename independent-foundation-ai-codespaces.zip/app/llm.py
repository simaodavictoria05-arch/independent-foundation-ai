from dataclasses import dataclass

@dataclass
class ReasoningOutput:
    hypotheses: list
    conclusion: str
    confidence: float
    limitations: list
    next_tests: list
    errors_checked: list

class MockReasoningProvider:
    """Provider de desenvolvimento. Substituir por LLM real na próxima fase."""

    def investigate(self, question: str, deep: bool = False) -> ReasoningOutput:
        hypotheses = [
            {
                "title": "Hipótese inicial",
                "statement": "A pergunta pode possuir mais de uma explicação compatível com os dados disponíveis.",
                "confidence": 0.35,
                "status": "NÃO CONFIRMADA",
                "supporting_evidence": [],
                "contradicting_evidence": [],
                "test": "Definir variáveis observáveis e uma previsão que diferencie as explicações."
            },
            {
                "title": "Hipótese alternativa",
                "statement": "Uma explicação diferente pode produzir os mesmos resultados observados.",
                "confidence": 0.25,
                "status": "ESPECULATIVA",
                "supporting_evidence": [],
                "contradicting_evidence": [],
                "test": "Construir um contraexemplo ou experimento computacional."
            }
        ]

        return ReasoningOutput(
            hypotheses=hypotheses,
            conclusion=(
                "O MVP ainda não possui evidência suficiente para uma resposta definitiva. "
                "A pergunta deve ser transformada em hipóteses testáveis e confrontada com evidências."
            ),
            confidence=0.30,
            limitations=[
                "O MVP ainda usa um provider de demonstração.",
                "Nenhuma fonte externa foi consultada.",
                "Uma simulação não é, por si só, prova da realidade."
            ],
            next_tests=[
                "Definir variáveis observáveis.",
                "Criar uma previsão falsificável.",
                "Procurar evidências favoráveis e contrárias.",
                "Executar uma simulação quando houver um modelo matemático."
            ],
            errors_checked=[
                "Não apresentar hipótese como fato.",
                "Não inventar evidência.",
                "Não transformar especulação em conclusão."
            ]
        )
