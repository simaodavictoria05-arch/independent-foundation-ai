RELIGION_TERMS = {
    "bible", "bíblia", "religião", "religiao", "teologia",
    "teológico", "teologico", "evangelho"
}

HISTORICAL_TERMS = {
    "newton", "isaac newton", "einstein", "albert einstein"
}

def filter_text(text: str, religion=True, historical=True):
    lower = text.lower()
    blocked = []
    if religion:
        blocked += [x for x in RELIGION_TERMS if x in lower]
    if historical:
        blocked += [x for x in HISTORICAL_TERMS if x in lower]
    return sorted(set(blocked))
