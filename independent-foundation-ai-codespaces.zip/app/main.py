from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from .memory import init_db, recent
from .engine import InvestigationEngine
from .models import InvestigationRequest

app = FastAPI(
    title="Independent Foundation AI",
    version="0.1.0"
)

init_db()
engine = InvestigationEngine()

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def home():
    return FileResponse("static/index.html")

@app.post("/api/investigate")
def investigate(req: InvestigationRequest):
    return engine.investigate(req.question, req.settings)

@app.get("/api/memory")
def memory():
    return recent()
