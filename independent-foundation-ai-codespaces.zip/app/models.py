from pydantic import BaseModel, Field
from typing import Optional, List

class Settings(BaseModel):
    religion_filter: bool = True
    historical_filter: bool = True
    deep_research: bool = False

class InvestigationRequest(BaseModel):
    question: str = Field(min_length=3, max_length=4000)
    settings: Settings = Settings()

class InvestigationResponse(BaseModel):
    problem: str
    classification: str
    hypotheses: List[dict]
    conclusion: str
    confidence: float
    limitations: List[str]
    next_tests: List[str]
    errors_checked: List[str]
