import sqlite3
from pathlib import Path
from datetime import datetime

DB = Path("data/knowledge.db")
DB.parent.mkdir(exist_ok=True)

def connect():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = connect()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS investigations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT NOT NULL,
        result TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS hypotheses(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        investigation_id INTEGER,
        title TEXT,
        statement TEXT,
        confidence REAL,
        status TEXT,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS errors(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        investigation_id INTEGER,
        description TEXT,
        cause TEXT,
        correction TEXT,
        created_at TEXT NOT NULL
    );
    """)
    c.commit()
    c.close()

def save_investigation(question, result, hypotheses):
    c = connect()
    now = datetime.utcnow().isoformat()
    cur = c.execute(
        "INSERT INTO investigations(question,result,created_at) VALUES(?,?,?)",
        (question, result, now)
    )
    iid = cur.lastrowid
    for h in hypotheses:
        c.execute(
            """INSERT INTO hypotheses
            (investigation_id,title,statement,confidence,status,created_at)
            VALUES(?,?,?,?,?,?)""",
            (iid, h["title"], h["statement"], h["confidence"], h["status"], now)
        )
    c.commit()
    c.close()

def recent(limit=20):
    c = connect()
    rows = c.execute(
        "SELECT id,question,result,created_at FROM investigations ORDER BY id DESC LIMIT ?",
        (limit,)
    ).fetchall()
    c.close()
    return [dict(r) for r in rows]
