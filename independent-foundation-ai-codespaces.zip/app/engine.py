from .filters import filter_text
from .llm import MockReasoningProvider
from .memory import save_investigation

class InvestigationEngine:
    def __init__(self):
        self.provider = MockReasoningProvider()

    def investigate(self, question, settings):
        blocked = filter_text(
            question,
            religion=settings.religion_filter,
            historical=settings.historical_filter
        )

        if blocked:
            return {
                "problem": question,
                "classification": "FILTRO_ATIVADO",
                "hypotheses": [],
                "conclusion": "A pergunta contém termos fora do domínio configurado: " + ", ".join(blocked),
                "confidence": 1.0,
                "limitations": ["O filtro configurado impediu esta investigação."],
                "next_tests": [],
                "errors_checked": ["Filtro de domínio aplicado antes do raciocínio."]
            }

        out = self.provider.investigate(question, settings.deep_research)
        result = {
            "problem": question,
            "classification": "PERGUNTA_FUNDAMENTAL",
            "hypotheses": out.hypotheses,
            "conclusion": out.conclusion,
            "confidence": out.confidence,
            "limitations": out.limitations,
            "next_tests": out.next_tests,
            "errors_checked": out.errors_checked
        }
        save_investigation(question, out.conclusion, out.hypotheses)
        return result
